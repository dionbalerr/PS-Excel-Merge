from dbfread import DBF
import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import NamedStyle, Font, Border, Side, Alignment
from datetime import datetime

print("Starting... Merging...")

# Load DBF file
dbf_file = "DELIVERY.dbf"
table = DBF(dbf_file)

# Convert to DataFrame
df = pd.DataFrame(iter(table))

today = datetime.now()
save_file = f"PS DELIVERY {today.strftime(('%m%d'))}"
# print(save_file)

# Save to Excel
df.to_excel(f"{save_file}.xlsx", index=False)

wb = load_workbook(f"{save_file}.xlsx")
ws = wb.active
ws.title = "DELIVERY"

ws.insert_cols(3)
ws.insert_cols(3)
ws.insert_cols(2)

print("DRIVER, FROM, TO： columns added")

sheet_name = ["Sheet1", "Sheet2"]
copy_dbf = ["DRIVER.dbf", "DELISITE.dbf"]

for i in range(len(sheet_name)):
    ws = wb.create_sheet(title=f"{sheet_name[i]}")
    dbf_file = f"{copy_dbf[i]}"
    table = DBF(dbf_file)
    df = pd.DataFrame(iter(table))

    for col_idx, col_name in enumerate(df.columns, start=1):
        ws.cell(row=1, column=col_idx, value=col_name)  # Write column names in first row

    for row_idx, row in enumerate(df.itertuples(index=False), start=2):  # Start from row 2
        for col_idx, value in enumerate(row, start=1):
            ws.cell(row=row_idx, column=col_idx, value=value)

print("Sheet1, Sheet2 created and copied over from DRIVER and DELISITE")

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]

    # Read all rows (excluding headers)
    rows = list(ws.iter_rows(min_row=2, values_only=True))

    # Separate rows where Column A is empty but Column B has data
    isolated_rows = [row for row in rows if row[0] in (None, "") and row[1] not in (None, "")]

    # Sort by col A, if is DELIVERY, also sort by date
    if sheet_name == "DELIVERY":
        sorted_rows = sorted([row for row in rows if row[0] not in (None, "")], key=lambda x: (x[0], x[6]))
    else:
        sorted_rows = sorted([row for row in rows if row[0] not in (None, "")], key=lambda x: x[0])

    # Clear old data (excluding header)
    ws.delete_rows(2, ws.max_row)  # Removes all data below the header

    # Write sorted rows back
    for row_data in sorted_rows:
        ws.append(row_data)  # Appends row at the bottom of existing data

    # Append isolated rows at the bottom
    for row_data in isolated_rows:
        ws.append(row_data)  # Places them after sorted rows

print("All sheets sorted by column A!")

ws = wb.worksheets[0]
# Define the Excel date format (1-Jul)
date_format = NamedStyle(name="custom_date")
date_format.number_format = "D-MMM"  # Format as "1-Jul"

# Ensure style is added to workbook to avoid duplication errors
if "custom_date" not in wb.named_styles:
    wb.add_named_style(date_format)

# Identify Column G (assuming the header is in row 1)
col_index = 7  # Column G is the 7th column

# Loop through each cell in Column G (starting from row 2 to skip the header)
for row in range(2, ws.max_row + 1):
    cell = ws.cell(row=row, column=col_index)

    # Try to parse the value as a date if it's not already a datetime object
    if isinstance(cell.value, str):
        try:
            # Convert string to datetime (handling multiple formats)
            cell.value = datetime.strptime(cell.value, "%d/%m/%Y")  # Example: "01/07/2023"
        except ValueError:
            try:
                cell.value = datetime.strptime(cell.value, "%Y-%m-%d")  # Example: "2023-07-01"
            except ValueError:
                continue  # Skip if not a recognizable date format

    # Apply the date format
    cell.style = date_format

print("Column G formatted to 'D-MMM' format successfully!")

ws["A1"] = ""
ws["B1"] = "DRIVER"
ws["C1"] = ""
ws["D1"] = "FROM"
ws["E1"] = "TO"
ws["F1"] = "DO NO"
ws["G1"] = "DELI_DATE"
ws["H1"] = "QTY"
ws["I1"] = "UNIT"
ws["J1"] = "RM"

for row in range(2, ws.max_row+1):
    ws[f"B{row}"] = f'=VLOOKUP($A{row}, Sheet1!$A:$H, 2)'
    ws[f"D{row}"] = f'=VLOOKUP($C{row}, Sheet2!$A:$G, 2)'
    ws[f"E{row}"] = f'=VLOOKUP($C{row}, Sheet2!$A:$G, 3)'
    ws[f"I{row}"] = f'=VLOOKUP($C{row}, Sheet2!$A:$G, 6)'
    ws[f"J{row}"] = f'=(H{row}*I{row})'

print("VLOOKUP done!")


# Add subtotal rows
count = 0
row = 2
max_row = ws.max_row+1

while row < max_row:
    cell_current = ws[f"A{row}"].value
    cell_next = ws[f"A{row+1}"].value  # Look at the next row

    if cell_current != cell_next:
        count += 1

    row += 1

# print(count)
ws.row_dimensions.group(2, ws.max_row + count-1, outline_level=1)

count = 0
row = 2
# Dynamically adjust max_row as rows shift
while row < max_row:
    cell_current = ws[f"A{row}"].value
    cell_next = ws[f"A{row+1}"].value  # Look at the next row

    if cell_current != cell_next:
        ws.move_range(f"A{row+1}:J{max_row}", rows=1, cols=0, translate=True)  # Move everything below down by 1 row

        col_A_cur = f"A{row}"
        ws[f"A{row+1}"] = f'=CONCATENATE({col_A_cur}, " Total")'
        ws[f"A{row+1}"].font = Font(bold=True)

        # print(count)

        col_H_sub_start = f"H{row-count}"
        col_H_cur = f"H{row}"
        ws[f"H{row+1}"] = f'=SUBTOTAL(9, {col_H_sub_start}:{col_H_cur})'

        col_J_sub_start = f"J{row-count}"
        col_J_cur = f"J{row}"
        ws[f"J{row+1}"] = f'=SUBTOTAL(9, {col_J_sub_start}:{col_J_cur})'

        ws.row_dimensions.group(row-count, row, outline_level=2)

        max_row += 1  # Update max_row since we added a row
        row += 1  # Skip the newly inserted row
        count = 0

    else:
        count += 1

    row += 1  # Move to the next row normally

print("Added Subtotal rows, grouped rows")

ws[f"A{ws.max_row}"] = "Grand Total"
ws[f"H{ws.max_row}"] = f'=SUBTOTAL(9, H2:H{ws.max_row-1})'
ws[f"J{ws.max_row}"] = f'=SUBTOTAL(9, J2:J{ws.max_row-1})'

ws[f"A{ws.max_row}"].font = Font(bold=True)
print("Added Grand Total rows")

# Apply number format to column H-J (example: "0.00" for two decimal places)
for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=8, max_col=10):  # Column H,J is 8,10th column
    for cell in row:
        cell.number_format = "0.00"  # Displays 2 decimal places without altering actual values

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if (len(str(cell.value)) > max_length and "CONCATENATE" not in str(cell.value)
                        and "SUBTOTAL" not in str(cell.value) and ", 6)" not in str(cell.value)):
                    max_length = len(cell.value)
            except:
                pass
        adjusted_width = max_length + 5
        ws.column_dimensions[column_letter].width = adjusted_width

print("Column width adjusted")

ws = wb.worksheets[0]

# Freeze + no border
ws.freeze_panes = ws["A2"]
print("Header freezed")

# Borders
side = Side(border_style=None)
no_border = Border(
    left=side,
    right=side,
    top=side,
    bottom=side,
)

# Select first row
for cell in ws[1]:
    cell.border = no_border
    cell.font = Font(bold=True)
    cell.alignment = Alignment(horizontal="left")

print("Header: no border, bold, align left")


wb.save(f"{save_file}.xlsx")
print(f"Done! File '{save_file}.xlsx' created!")

input("Press Enter key to close this window")