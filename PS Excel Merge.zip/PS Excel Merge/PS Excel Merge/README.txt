# PS Excel Merge

PS Excel Merge is written in Python openpyxl to deal with automating VLOOKUP .dbf files (DELIVERY, DRIVER and DELISITE). Creates a new excel file "PS DELIVERY MMDD". MMDD is today's date.


## How to Run
### 1. Executable
- Download the `PS Excel Merge` zip file and unzip it
- Put DELIVERY, DRIVER and DELISITE in the `PS Excel Merge` folder
- Run `main.exe` **(WINDOWS only)**


## Usage

```cmd
Starting... Merging...
DRIVER, FROM, TO¡G columns added
Sheet1, Sheet2 created and copied over from DRIVER and DELISITE
All sheets sorted by column A!
Column G formatted to 'D-MMM' format successfully!
VLOOKUP done!
Added Subtotal rows, grouped rows
Added Grand Total rows
Column width adjusted
Header freezed
Header: no border, bold, align left
Done! File 'PS DELIVERY MMDD.xlsx' created!
Press Enter key to close this window
```


## Misc
1. Only reads .dbf files
2. Files have to be in the same folder as `main.py` or `main.exe`